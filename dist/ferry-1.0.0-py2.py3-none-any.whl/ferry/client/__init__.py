from ferry.client.client_recommendations import Client

if __name__ == "__main__":
    client = Client()
